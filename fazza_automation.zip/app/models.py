from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class Company(Base):
    __tablename__ = "companies"
    id = Column(String, primary_key=True)
    name = Column(String)
    instagram_account_id = Column(String, nullable=True)
    instagram_access_token = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    automations = relationship("Automation", back_populates="company")

class Automation(Base):
    __tablename__ = "automations"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(String, ForeignKey("companies.id"))
    name = Column(String)
    platform = Column(String, default="instagram")
    triggers = Column(JSON)
    actions = Column(JSON)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    company = relationship("Company", back_populates="automations")

class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(String, ForeignKey("companies.id"))
    platform = Column(String)
    external_id = Column(String, index=True)
    contact_username = Column(String)
    last_message_at = Column(DateTime, default=datetime.utcnow)

class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True, index=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id"))
    sender_type = Column(String)
    content = Column(Text)
    sent_at = Column(DateTime, default=datetime.utcnow)

class Contact(Base):
    __tablename__ = "contacts"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(String)
    platform = Column(String)
    external_id = Column(String, index=True)
    username = Column(String)
    tags = Column(JSON, default=[])

class AnalyticsLog(Base):
    __tablename__ = "analytics_logs"
    id = Column(Integer, primary_key=True, index=True)
    automation_id = Column(Integer)
    executed_at = Column(DateTime, default=datetime.utcnow)
    success = Column(Boolean)
    trigger_data = Column(JSON)
