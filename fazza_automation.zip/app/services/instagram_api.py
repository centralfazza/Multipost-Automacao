import requests

class InstagramAPI:
    def __init__(self, token): self.token = token
    def reply_to_comment(self, comment_id, text):
        return requests.post(f"https://graph.instagram.com/v21.0/{comment_id}/replies", json={"message": text}, params={"access_token": self.token}).json()
    def send_dm(self, user_id, text):
        return requests.post(f"https://graph.instagram.com/v21.0/me/messages", json={"recipient": {"id": user_id}, "message": {"text": text}}, params={"access_token": self.token}).json()
