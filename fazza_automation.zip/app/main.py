from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base
from .routes import automations, conversations, webhooks, companies, analytics

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Fazza Automation API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "healthy"}

app.include_router(automations.router, prefix="/api/automations", tags=["Automations"])
app.include_router(conversations.router, prefix="/api/conversations", tags=["Conversations"])
app.include_router(webhooks.router, prefix="/webhooks", tags=["Webhooks"])
app.include_router(companies.router, prefix="/api/companies", tags=["Companies"])
app.include_router(analytics.router, prefix="/api/analytics", tags=["Analytics"])
